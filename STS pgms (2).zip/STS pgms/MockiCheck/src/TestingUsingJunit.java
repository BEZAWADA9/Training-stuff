import static org.junit.Assert.*;

//import org.junit.Test;

	
	import static org.junit.Assert.*;

	import org.junit.Test;
	public class TestingUsingJunit{

		//1. Factorial of 0 is 1.
		//2. Factorial of 1 is 1.
		//3. Factorial of 5 is 120.
		//4. Factorial of Negative Numbers cannot be calculated.
		
		@Test
		public void FactorialOfZeroIsOne() {
			Pojo p=new Pojo();
			assertEquals(1,p.isFactorial(0));
		}
		
		@Test
		public void FactorialOfOneIsOne() {
			Pojo p=new Pojo();
			assertEquals(1,p.isFactorial(1));
		}
		@Test
		public void FactorialOfFiveIsOne() {
			Pojo p=new Pojo();
			assertEquals(120,p.isFactorial(5));
		}
		@Test(expected=IllegalArgumentException.class)
		// Putting �expected� inside the @Test annotation tells
		//the JUnit runner that the expected outcome is to throw the specified exception
		public void FactorialOfNegativeNumbersCannotBeCalculated() {
			Pojo p=new Pojo();
			p.isFactorial(-3);
			
		}
		
		@Test
		public void OneFifyisArmstrong() {
			Pojo p=new Pojo();
			//assertEquals(153,p.isFactorial(153));
			p.isArmstrong(153);
		}
		@Test 
		public void twentyISNotArmStrong(){
			Pojo p= new Pojo();
			p.isArmstrong(20);
			
		}

	}



