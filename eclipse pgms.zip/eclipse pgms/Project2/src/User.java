import java.util.Scanner;

public class User {

	
	static ABCBAnk bank=new ABCBAnk();
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)  {
		

while(true)

{
	
	System.out.println("please select one option");

	System.out.println("1.for  create account");

	System.out.println("2.for Deposit amoutn ");

	System.out.println("3.for withdraw amoutn ");
	
	System.out.println("4.for fundtransfer");
	
	System.out.println("5.for Exit");

	int option=sc.nextInt();

	

switch(option)

{
case 1 : 
	
System.out.println("enetr  account number to create account");
	
	int initialAccountNumber=sc.nextInt();
	System.out.println("enetr amount for  deposit");
	int deposit=sc.nextInt();
	
	
	try{
		
	
	String accountCreated=bank.createAccount(initialAccountNumber, deposit);
	
	System.out.println(accountCreated);
	
    break;
	}
	catch(Exception e){
		System.out.println(e);
	}
    
case 2:
	
	System.out.println("enter account number to deposit");
	int amount=sc.nextInt();
	
	
	int accountNumber=sc.nextInt();
	try{
	int depositedAmount=bank.depositAmount(accountNumber, amount);
	
	System.out.println("deposited amount is " +depositedAmount);
	break;}
	catch(Exception e){
		System.out.println(e);
	}
case 3:
	
	System.out.println("enter account number to withdraw");
	
	int accountNumberWithdraw=sc.nextInt();
	
	System.out.println("enetr amount to withdraw");
	
	int withdrawAmount=sc.nextInt();
	
	try{
	int withdrawn=bank.withdrawAmount(accountNumberWithdraw, withdrawAmount);
	
     System.out.println(" withdrawn money is" + withdrawn);
	break;}
	catch(Exception e){
		System.out.println(e);
	}
	
case 4: 
	System.out.println("you have selected fund transfer option");
	
	System.out.println("Enter sender account number");
	
	int sender=sc.nextInt();
	
	System.out.println("Enter Receiver account number");
     
	int receiver=sc.nextInt();
	
	
	System.out.println("Enter fun amount to be transfered");
	
	int fundAmount=sc.nextInt();
	try{
	
   int transferedFund[]= bank.fundTransfer(sender, receiver, fundAmount);
   
   System.out.println("sender amount after the fund transfer Transaction " + transferedFund[0]);
   
   System.out.println(" receiver amount after the fund transfer Transaction  " + transferedFund[1]);
	}
	catch(Exception e){
		System.out.println(e);
	}
}

}

	}

}
