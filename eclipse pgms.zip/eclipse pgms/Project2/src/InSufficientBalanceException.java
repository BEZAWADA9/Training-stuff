
public class InSufficientBalanceException extends Exception{

}
