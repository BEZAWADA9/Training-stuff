/**
 * Created by mbezawad on 6/16/2016.
 */
app.factory("service", function ($http) {
    return function (callback) {
        $http({
            method:'GET',
            url:"../lib/JSONFile.json"
        }).then(function (response) {
            console.log(response)
            callback(response.data);

        },function (response) {
            console.log(response)

        })

    }

});
