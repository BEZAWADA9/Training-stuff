
public class StringEx {

	public static void main(String[] args) {
		
       
		String str1="murali";
		
		String str2=new String("murali");
		
		String str3="murali";
		
		
		if(str1==str2){
			System.out.println("str1 and str2 reference variables  are equal");
		}
		
		else
			System.out.println("str1 and str2 reference variables  are not equal");
  		if(str1.equals(str2)){
			System.out.println("str1 and str2 are equal");
		}
		else
			System.out.println("str1 and str2 are not equal");
			


		if(str1==str3){
			System.out.println("str1 and str3 reference variables  are equal");
		}
		
		else
			System.out.println("str1 and str3 reference variables  are not equal");
	
	
	
	if(str1.equals(str3)){
		System.out.println("str1 and str3 are equal");
	}
	else
		System.out.println("str1 and str3 are not equal");
		


}
}