
public class TypeCastingDemo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		int n=10;
		byte b=10;
		float s=2.2f;
		n=b;
		int x=(int)s;
		 System.out.println("implicit type casting"+n);
		
		 System.out.println("implicit type casting"+x);	
		
	}

}
