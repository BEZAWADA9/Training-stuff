package ContextParam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SecondServlet
 */
@WebServlet("/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		HttpSession hs=request.getSession(false);
		String lastName=request.getParameter("lastName");
		
		pw.println("This is SecondServlet");
		String firstName=(String)hs.getAttribute("firstName");
		
		//String lastName=(String)hs.getAttribute("lastName");
		
		
		pw.println("<br>");
		pw.println("firstName is" + firstName);
		pw.println("<br>");
		
		pw.println("lastName is" + lastName);
		pw.println("<br>");
		
		hs.setAttribute("firstName", firstName);
		hs.setAttribute("lastName", lastName);
	
		pw.println("<br>");
		
		//HTML code For Qualification
		
		pw.println("<html>");
		pw.println("<body>");
		pw.println("Enter Qualification");
		pw.println("<form action=ThirdServlet >");
		
		pw.println("<input type =text name =qualification >");
		
		pw.println("<input type =submit value =Submit >");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
