package com.capgemini.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.model.Customer;
import com.capgemini.service.CustomerService;
import com.capgemini.service.ICustomerService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//ICustomerService cs=new CustomerService();
ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
CustomerService cs=(CustomerService)context.getBean("customerService",com.capgemini.service.CustomerService.class);
System.out.println(cs.findAll());
//Creating customers
/*Customer cust1=cs.createCutsomer("Murali", "Bezawada");
Customer cust2=cs.createCutsomer("Nag", "Bezawada");
Customer cust3=cs.createCutsomer("Naresh", "Bezawada");*/
	}

}
