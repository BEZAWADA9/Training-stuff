
public class StaticEx1 {

	
	int a;
	StaticEx1(){
		System.out.println("constructor");
	}
	
	{
		System.out.println("Instance Block1");
		
	}
	{
		System.out.println("Instance Block2");
	}
	
	static
	{
		System.out.println("Static Block");
		
		//random();
	}	
		void random(){
			System.out.println("nonstatic random");
			for(int i=0;i<10;i++){
				System.out.println(" "+ Math.random());
				
				
			}
			StaticEx1.random1();
		}	
			static void random1(){
				System.out.println("static random");
				for(int i=0;i<10;i++){
					System.out.println(" "+ Math.random());
					
				}
			
			
			
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int z;
		//a=20;
		StaticEx1 s=new StaticEx1();
		
		StaticEx1 s1=new StaticEx1();
		s1.random();
	}

}
