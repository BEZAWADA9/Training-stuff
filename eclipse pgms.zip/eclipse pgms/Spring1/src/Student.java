
public class Student {

	private int id;
	private String name;
	
	Student(String n){
		System.out.println("From String constructor" + n);
	}
	Student(int num){
		System.out.println("From int constructor" + num);
	}
	
	Student (String name, int number){
		System.out.println("from two argument const "+ name+ " "+ number);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
