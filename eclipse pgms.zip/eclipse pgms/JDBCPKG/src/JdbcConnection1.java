import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class JdbcConnection1 {
		


	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		try
		{ 	
Class.forName("com.mysql.jdbc.Driver");

java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/murali","root","root");

System.out.println("Connected");


java.sql.Statement st=con.createStatement();



int result=st.executeUpdate("insert into student1 values('mani',1211,532,'d','1992-12-25')");

java.sql.ResultSet rs=st.executeQuery("select * from student1");

System.out.println(result);

while(rs.next())

{
	
	System.out.println(  rs.getString(1) + " " + rs.getInt(3) + " " + rs.getString(4));
	
}

//con.close();
System.out.println("Connetcion closed");
	}
	
	catch(Exception e)
	
	{
		System.out.println(e);
		
	}
		
		finally{
			
			
		}
	}
}

