/**
 * Created by mbezawad on 6/13/2016.
 */

app.controller('myCtrl', function($scope,service){
    $scope.sorting = "";
    $scope.searchText="";
    $scope.values=function (blog){
        blog.votes++;
    };
    //$scope.novels=

    var callback=function (data) {
        $scope.novels=data
    }
        $scope.novels=service(callback)
    })



/*
app.controller('myCtrl', function($scope){
    $scope.sorting = "";
    $scope.searchText="";
    $scope.values=function (blog){
        blog.votes++;
    };
    $scope.novels=[
        {
            title:"The Guide",
            author:"R.K. Narayan",
            cover:"../Images/TheGuide.jpg",
            summary:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim efficitur dapibus. Vivamus vel lorem quis libero aliquam scelerisque Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim .",
            date:1985,
            votes:85
        },
        {
            title:"The Rage of Angels",
            author:"Sidney Sheldon",
            cover:"../Images/TheRageOfAngels.jpg",
            summary:"Lorem ipsum dolor sit amet,consectetur adipiscing elit.Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim efficitur dapibus. Vivamus vel lorem quis libero aliquam scelerisque Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim .",
            date:1976,
            votes:90
        },

        
        {
            title:"13 Steps To Bloody Good Luck",
            author:"Ashwin Sanghi",
            cover:"../Images/BloodyGoodLuck.jpg",
            summary:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim efficitur dapibus. Vivamus vel lorem quis libero aliquam scelerisque Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim .",
            date:2005,
            votes:95},
        {
            title:"The Monk Who Sold His Ferrari",
            author:"Robin Sharma",
            cover:"../Images/MonkWhoSoldHisFerrari.jpg",
            summary:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim efficitur dapibus. Vivamus vel lorem quis libero aliquam scelerisque Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut imperdiet vestibulum felis eu lobortis. Vestibulum suscipit purus massa, vitae molestie enim .",
            date:2003,
            votes:98}
    ];
});*/
