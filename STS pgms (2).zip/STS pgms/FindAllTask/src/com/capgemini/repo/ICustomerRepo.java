package com.capgemini.repo;

import java.util.List;

import com.capgemini.model.Customer;

public interface ICustomerRepo {

List<Customer> findAll();

}