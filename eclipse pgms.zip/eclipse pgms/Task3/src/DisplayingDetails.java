import java.util.Scanner;
public class DisplayingDetails {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the rollnumber");
		String rollnumber=sc.next();
		System.out.println("enter the number of courses you want");
		int no_of_courses=sc.nextInt();
		System.out.println("enter the courses");
		String courses[]=new String[no_of_courses];
		for(int i=0;i<courses.length;i++)
		
			courses[i]=sc.next();
			System.out.println("Candidate Rollnumber is" + rollnumber);
			
			System.out.println("courses which are taken by " + rollnumber + "are");
		for(String coursestaken:courses)
		{
			System.out.println(coursestaken);
		}
		
	}

}
