
interface InterfaceEx1 {
  int a=10;
	 void check();
}

class InterfaceEx implements InterfaceEx1

{
public 	void check(){
		
		System.out.println("this is class");
	}
	
public static void main(String a[]){
	
	InterfaceEx i=new InterfaceEx();
	i.check();
}
}
	

