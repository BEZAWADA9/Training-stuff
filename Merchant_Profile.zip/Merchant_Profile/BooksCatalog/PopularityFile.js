/**
 * Created by mbezawad on 6/15/2016.
 */





app.filter("stars", function(){

    var max = 0;
    return function (value,total)
        {
            total =parseInt(total)
            if(total>max)
                max=total
                total=Math.round((5*total)/max)
                for(var i=0;i<total;i++){
                    value.push(i)
                }


return value;
        }

});  
