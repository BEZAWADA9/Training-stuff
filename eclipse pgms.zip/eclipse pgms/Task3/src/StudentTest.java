import java.util.Scanner;
public class StudentTest {

	  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Student student=new Student();
   Scanner sc=new Scanner(System.in);
  
   
  
   
   System.out.println("enter student rollnumber");
  // int n=sc.nextInt();
   
  student.setrollNumber(sc.nextInt());
  
  System.out.println("student rollnumber is "+student.getrollNumber());
  
  System.out.println("enter student name");
  
student.setName( sc.next());


    System.out.println("student name is " +student.getName());
  System.out.println("enter number of student courses");
  
 int n=sc.nextInt();
   
   
 
	String[] arr=new String[n];
  for(int i=0;i<n;i++){
	  System.out.println("enter  course names");
	 arr[i]=sc.next();
	 
	 // student.setCourses(sc.next());
	  
  }
   student.setCourses(arr);
  
  for(int i=0;i<student.getCourses().length;i++){
	  
	System.out.println("Student courses are " +  student.getCourses()[i]);  // student.getCourses()[i];
	  
	// String[] arr2 = student.getCourses();
	}

}}
