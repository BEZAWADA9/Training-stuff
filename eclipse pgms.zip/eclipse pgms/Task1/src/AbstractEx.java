abstract class Parent1{
	
	void first(){
		System.out.println("this is first method");
		
	}
	
	abstract void second();
}
public class AbstractEx  extends Parent1{

	void second(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
