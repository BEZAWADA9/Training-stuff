
import java.util.Scanner;

public class User {

	static Scanner sc=new Scanner(System.in);
	
	
	
	
	static ABCBank bank=new ABCBank();
	
	
	
	
	
	public static void main(String[] args) throws InvalidAccountNumberException, InsufficientBalanceException {
		

while(true)

{
	
	System.out.println("please select one option");

	System.out.println("1.for  create account");

	System.out.println("2.for Deposit amoutn ");

	System.out.println("3.for withdraw amoutn ");
	
	System.out.println("4.for fundtransfer");
	
	System.out.println("5.for Exit");

	int option=sc.nextInt();

	

switch(option)

{
case 1 : 
	System.out.println("enter Customer Address details");
	
	System.out.println("enter Customer name");
	
	String customerName=sc.next();
	
	System.out.println("enter Customer Address");
	
	String customerCity=sc.next();
	
System.out.println("enter Customer Pincode");
	
	int customerPincode=sc.nextInt();
	
	 Customer customer=new Customer(customerName, new Address(customerCity,customerPincode) );
	 
System.out.println("enetr  account number to create account");
	
	int initialAccountNumber=sc.nextInt();
	System.out.println("enetr amount for  deposit");
	int deposit=sc.nextInt();
	
	
	
	String accountCreated=bank.createAccount(initialAccountNumber, deposit, customer);
	
	System.out.println(accountCreated);
	
    break;
    
case 2:
	
	System.out.println("enter account number to deposit");
	int amount=sc.nextInt();
	
	
	int accountNumber=sc.nextInt();
	int depositedAmount=bank.depositAmount(accountNumber, amount);
	
	System.out.println("deposited amount is " +depositedAmount);
	break;
case 3:
	
	System.out.println("enter account number to withdraw");
	
	int accountNumberWithdraw=sc.nextInt();
	
	System.out.println("enetr amount to withdraw");
	
	int withdrawAmount=sc.nextInt();
	
	int withdrawn=bank.withdrawAmount(accountNumberWithdraw, withdrawAmount);
	
     System.out.println(" withdrawn money is" + withdrawn);
	break;
	
case 4: 
	System.out.println("you have selected fund transfer option");
	
	System.out.println("Enter sender account number");
	
	int sender=sc.nextInt();
	
	System.out.println("Enter Receiver account number");
     
	int receiver=sc.nextInt();
	
	
	System.out.println("Enter fun amount to be transfered");
	
	int fundAmount=sc.nextInt();
	
   int transferedFund[]= bank.fundTransfer(sender, receiver, fundAmount);
   
   System.out.println("sender amount after the fund transfer Transaction " + transferedFund[0]);
   
   System.out.println(" receiver amount after the fund transfer Transaction  " + transferedFund[1]);
}

}

	}

}
