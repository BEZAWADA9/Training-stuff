
public class ArithmeticOperations {

	void add(int a,int b)
	{
	System.out.println("addition of a+b is" + (a+b));
	}
	
	
	void sub(int a,int b)
	{
	System.out.println("subtraction of a+b is" + (a-b));
	}
	
	void mult(int a,int b)
	{
	System.out.println("multplication of a+b is" + (a*b));
	}
	
	
	void div(int a,int b)
	{
	System.out.println("division of a+b is" + (a/b));
	}
	
	void mod(int a,int b)
	{
	System.out.println("mod of a+b is" + (a%b));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArithmeticOperations ao=new  ArithmeticOperations();
		 
		 ao.add(10,3);
		 ao.sub(10, 3); ao.mult(10, 3); ao.div(10, 3); ao.mod(10, 3);   // ao.sub(10, 3);
	}

}
