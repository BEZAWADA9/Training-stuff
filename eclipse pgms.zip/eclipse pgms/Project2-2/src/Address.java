
public class Address {
	private String city;
	private int pinNumber;
	public Address(String city, int pinNumber) {
		super();
		this.city = city;
		this.pinNumber = pinNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	

}
