import com.sun.management.GarbageCollectorMXBean;

public class SwitchCheck1 {
	
	
	protected void finalize(){
		
		System.out.println("Only few seconds");
	}
	
	
		public static int getSwitch(String str)
		{
		return (int) Math.round( Double.parseDouble(str.substring(1, str.length()-1)) );
		}
		public static void main(String args [])
		{
			switch(getSwitch(args[0]))
			{
				case 0 : System.out.println("Hello");
				case 1 : System.out.println("World"); break;
				default : System.out.println("Good Bye");
			}
			
			
			SwitchCheck1 sc=new SwitchCheck1();
			
	sc.finalize();
			
			//GarbageCollector gc;
			//System.gc();
			Runtime.getRuntime().gc();
			
			sc.add();
			//System.out.println("It should not be printed");
		}
		 void add(){
			 System.out.println("Now object is no more");
		 }
		
	}



