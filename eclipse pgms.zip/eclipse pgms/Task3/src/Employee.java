
public class Employee {

	private int age;
	private String name;
 public void setName(String name){
	 this.name=name;
 }
 
 public String getName(){
	 if(name==null){
		 this.name="DefaultName";
		 return name;
	 }
	 
	 else
	 return name;
 }
}
