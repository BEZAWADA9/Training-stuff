import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializableEx1 implements Serializable{

	private String name;
	public SerializableEx1(String name){
		this.name=name;
		
		
	}
	
	
	
	@Override
	public String toString() {
		return "SerializableEx1 [name=" + name + "]";
	}



	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
FileOutputStream fs=new FileOutputStream(new File("D:\\Murali\\Multithreading\\src\\Thread2.java"));

ObjectOutputStream os=new ObjectOutputStream(fs);

os.writeObject(new SerializableEx1("Murali"));

os.writeObject(new SerializableEx1("Nag"));

//Now I am reading data from object whcih ahs been serialized

FileInputStream fis=new FileInputStream(new File("D:\\Murali\\Multithreading\\src\\Thread2.java"));

ObjectInputStream os1=new ObjectInputStream(fis);

SerializableEx1 sx1=(SerializableEx1)os1.readObject();



SerializableEx1 sx2=(SerializableEx1)os1.readObject();

System.out.println(sx1);
System.out.println(sx2);
	}

}







































































































































































