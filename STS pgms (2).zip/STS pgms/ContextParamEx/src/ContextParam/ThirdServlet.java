package ContextParam;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ThirdServlet
 */
@WebServlet("/ThirdServlet")
public class ThirdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ThirdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		
		HttpSession hs=request.getSession(false);
		
		String qualification=request.getParameter("qualification");
		
		String firstName=(String) hs.getAttribute("firstName");
		
		String lastName=(String) hs.getAttribute("lastName");
		
		pw.println("This is Third Servlet");
		pw.println("<br>");
		pw.println("firstName is " + firstName);
		pw.println("<br>");
		pw.println("lastName is "+ lastName);
		pw.println("<br>");
		pw.println("Qualification  is " + qualification);
		pw.println("<br>");
		hs.setAttribute("qualification", qualification);
		hs.setAttribute("firstName", firstName);
		hs.setAttribute("lastName", lastName);
		
		
		
		pw.println("<html>");
		pw.println("<body>");
		pw.println("Enter Marks");
		pw.println("<form action=FourthServlet >");
		
		pw.println("<input type =text name =marks >");
		
		pw.println("<input type =submit value =Submit >");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
