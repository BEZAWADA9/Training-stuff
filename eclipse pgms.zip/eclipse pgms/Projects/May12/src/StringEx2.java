
public class StringEx2 {

	public static void main(String[] args) {
		
		//String str1=new String("murali");
		//StringBuffer sb5=new StringBuffer();
		//String str5=sb5;
		String str1="murali";
		System.out.println("str1 value is " + str1);
		
		str1=str1+"bezawada";

		System.out.println("str1 value after concatination is " + str1);
		
		
		StringBuffer sb1=new StringBuffer(str1);
		sb1.append("hie");
		System.out.println(" " + sb1);
		
/*		
		String str2="muralibezawada";
		
		if(str1==str2){
			System.out.println("str1 and str2 reference variables  are equal");
		}
		
		else
			System.out.println("str1 and str2 reference variables  are not equal");
		
		
		
		if(str1.equals(str2)){
			System.out.println("str1 and str2 are equal based on content");
		}
		else
			System.out.println("str1 and str2 are not equal based on content");  */
	} 
    
}
