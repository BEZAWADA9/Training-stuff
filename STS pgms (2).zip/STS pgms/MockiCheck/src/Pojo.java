


	

	public class Pojo
	{
		
		
		public int isFactorial(int l){
			int result=l;
			if(l<0){
				throw new IllegalArgumentException();
			}
			if(l==0||l==1){
				return 1;
			}
			for(int i=1;i<l;i++){
				result=result*i;
			}
			 return result; 
			 }  
		
		

	public boolean isArmstrong(long l){
	    String num=""+l;
	    int noOfDigits=num.length();
	    long sum=0;
	    for(int i=0;i<noOfDigits;i++){
	    	char c=num.charAt(i);
	    	int digit=Integer.parseInt(c+"");
	    	sum=(long) java.lang.Math.pow(digit, noOfDigits);
	    }
	    if(sum==l){
	    	return true;
	    }
		return false;
	}
	
	
	}
	

