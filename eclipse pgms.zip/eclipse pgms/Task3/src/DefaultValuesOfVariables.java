
public class DefaultValuesOfVariables {

	
	private int var=50;
	char a;
	byte b;
	short s; int i; long l; float f; double d; boolean bl;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultValuesOfVariables o=new DefaultValuesOfVariables();	
System.out.println("Char value is "+ o.a);
System.out.println("Byte value is"+o.b);
System.out.println("short value is"+o.s);
System.out.println("long value is"+o.l);
System.out.println("float value is"+o.f);
System.out.println("double value is"+o.d);
System.out.println("boolean value is"+o.bl);
System.out.println("int value is"+o.i);
	}

}
