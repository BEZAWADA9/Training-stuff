import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreatingFileEx {

	public static void main(String[] args) throws IOException {
		
// BufferedReader br2=new BufferedReader(new FileWriter(new File("D:\\Murali\\Multithreading\\src\\automatic.txt")));
		
		//BufferedReader br2=new BufferedReader(new );
		
		
		BufferedWriter br2=new BufferedWriter(new FileWriter(new File("D:\\Murali\\Multithreading\\src\\automatic.txt")));
		
		File f=new File("D:\\Murali\\Multithreading\\src\\automatic2.txt");
		f.createNewFile();
		
		//f.delete();
		
		File f1=new File("D:\\Murali\\Multithreading\\src");
		
		
		File f4=new File("D:\\Murali\\Multithreading\\src\\changeautomatic");
		
	String[]  path=f1.list();
		
	
		for(String str:path)
		System.out.println(str);
		
		
	boolean bool=f.renameTo(f4);
	System.out.println(bool);
		
	}

}
