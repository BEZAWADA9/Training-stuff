import java.util.Scanner;
public class NullPointerExceptionEx {
//	int a=20
   
	
	public static void main(String a[]){
		
		String str=null;
		
	System.out.println(str);	
	}
	
	
/*	static Scanner sc=new Scanner(System.in);      
	 int a;
	NullPointerExceptionEx(int a){
		
		this.a=a;
	}
	
	public static void main(String[] args) {
	
//int a=
NullPointerExceptionEx[] ne=new NullPointerExceptionEx[15];
System.out.println("eneter how many a values you want");
 int n=sc.nextInt();
for(int i=0;i<4;i++)
{
	
	ne[i]=new NullPointerExceptionEx(20);
	System.out.println(ne[i].a);
}

		
	}*/

}
