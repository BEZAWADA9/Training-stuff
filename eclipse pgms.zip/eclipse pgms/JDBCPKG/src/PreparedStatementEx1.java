import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.ResultSetMetaData;

public class PreparedStatementEx1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");

		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/murali","root","root");
		
		PreparedStatement ps=con.prepareStatement("insert into student1 (name,stdmarks) values(?,?)");
		
		con.setAutoCommit(false);
		
	ps.setString(1,"vijay");
		
	ps.setInt(2,880);
		
		int i=ps.executeUpdate();
		
		System.out.println(i);
		
		
		
		con.rollback();
		
		
		//ps.executeUpdate("delete from student1 where name like 'vijay'");
		
		ResultSet rs= ps.executeQuery("select * from student1");
		
		while(rs.next()){
			
			System.out.println(rs.getString(1) + " " + rs.getInt(2) +" " + rs.getInt(3) +" " + rs.getString(4) +" " + rs.getString(5));
			
			
		}
		
		
		System.out.println("********************NOW RESULTSETMETADATA TASK******************************");
		
		java.sql.ResultSetMetaData rsmd=rs.getMetaData();
		
		System.out.println("Number of columns in a table are " + rsmd.getColumnCount());
		
		System.out.println("first columnt name is " + rsmd.getColumnName(1));
		
		System.out.println("first columnt type  is " + rsmd.getColumnTypeName(1));
		
	}

}
