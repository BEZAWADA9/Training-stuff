/**
 * Created by mbezawad on 6/13/2016.
 */
var app = angular.module('myApp', []);