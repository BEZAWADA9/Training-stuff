
public class CommandLineEx {

	public static void main(String[] args) {
		int i=Integer.parseInt(args[0]);
		
		int i1=Integer.parseInt(args[1]);
System.out.println(i+i1);

System.out.println(""+i+i1);

System.out.println(""+(i+i1));

	}

}
