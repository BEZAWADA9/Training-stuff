
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e=new Employee("Sachin");
		
		System.out.println(e);
	}

}
