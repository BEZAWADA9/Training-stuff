
public class Student {
	

	private int rollNumber;
private	String name;
private	String[] coursename;
	
	 public void setrollNumber(int rollNumber){
		 this.rollNumber=rollNumber;
	 }
	 
	 public int getrollNumber(){
		 return rollNumber;
		 
		 }
		 
	 
	 
	 public void setName(String name){
		 this.name=name;
	 }
	 
	 public String getName(){
		 return name;
		 
		 }
	
	 public void setCourses(String[] coursename){
		  this.coursename=coursename;
	 }
	 
	 public String[] getCourses(){
		  return coursename;
	 }
	 
		
}


