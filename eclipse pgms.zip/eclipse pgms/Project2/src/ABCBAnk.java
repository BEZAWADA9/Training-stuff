import java.util.LinkedList;

import javax.naming.InsufficientResourcesException;

public class ABCBAnk {

	LinkedList<Account> accounts=new LinkedList<Account>();
	
	Account accountHolder;
	
	//static int autoAccountNumber;
	
	public String createAccount(int accountNumber, int amount)

{
	
		//autoAccountNumber=accountNumber;
		
		//accountNumber+=1;
		
		if(amount>=500)
		{
			
		accountHolder= new Account (accountNumber , amount);
		
		accounts.add(accountHolder);
		
		
		//autoAccountNumber=accountNumber+1;
		
		System.out.println("accountnumber is" + accountNumber);
		return "Account has been added";
		
		}
		
		else 
			
			return "Account not created";
}
	

	
	
	private Account searchAccount(int accountNumber)   throws InvalidAccountNumberException
	{
		//
		
		// if(accounts.)
			
			for(Account ac:accounts){
				
				if(ac.getAccountNumber()==accountNumber)
					
					return ac;
				
			}
		
			 
				throw new InvalidAccountNumberException();
			
			
		
	 
		
	}
	
	public int withdrawAmount(int accountNumber, int amount)throws InvalidAccountNumberException,InSufficientBalanceException{
		
		Account acholder=searchAccount(accountNumber);
		
		if(acholder.getAmount()-amount>0){
			
			amount=acholder.getAmount()-amount;
			
			return amount;
			
		}
		
		else 
			
			throw new InSufficientBalanceException();
	}
	
	 
	public int depositAmount(int accountNumber, int amount) throws InvalidAccountNumberException{
		
		Account depositAccountHolder=searchAccount(accountNumber);
		
			depositAccountHolder.setAmount(amount);
			
	
		
		return amount;
	}
	
	public int[] fundTransfer(int sender, int receiver, int fundTransfer) throws InvalidAccountNumberException,InSufficientBalanceException
	
	
	{
		
		System.out.println(" I am in fundtransfer method");
		
		Account account1=searchAccount(sender);
		
		Account account2=searchAccount(receiver);
		
		
		System.out.println(" account number of sender is " + account1.getAccountNumber());
		
		System.out.println(" account number of sender is " + account2.getAccountNumber());
		
		if(account1.getAmount()>=fundTransfer){
			account1.setAmount(account1.getAmount()-fundTransfer);
			account2.setAmount(account2.getAmount()+fundTransfer);
			int[] arr={account1.getAmount(),account2.getAmount()};
			return arr;
		}
		
		/*int senderAmount;
		
		
		if(accountHolder.getAccountNumber()==sender && accountHolder.getAccountNumber()==receiver){
			
			 senderAmount=accountHolder.getAmount()-fundTransfer;
			
			int receiverAmountCredited=accountHolder.getAmount() + fundTransfer;
			
			 accountHolder.setAmount(receiverAmountCredited);
			 
			 
			 return senderAmount;
		}
		
		else
			
			return 0;*/
		else 
			
			throw new InSufficientBalanceException();
	}
	
	
	
}
