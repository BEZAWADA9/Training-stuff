
 class Child extends Parent {

	
	void add(){
		System.out.println("This is add method in child class");
		super.add();
	}
	
	void mult(){
		System.out.println("This is mult method in child class");
		super.add();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child c=new Child();
		
	//	c.add();
		
		//Child c1=(Child) new Parent();
		
		Parent p=new Child();
		
		Child c1=(Child)p;
		c1.mult();
		c1.sub();
		
	//c1.mult();
	//	c1.sub();
	//	p.add();
	//	p.sub();
		
	}

}
