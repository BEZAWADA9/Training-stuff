
public class ConstructorDemo {
	int b;
	public ConstructorDemo(int b)
	{
		System.out.println("This is constructor");
		this.b=b;
		//b=b;
	}

	public static void main(String args[])
	{
		ConstructorDemo cd=new ConstructorDemo(30);
		System.out.println("b value is" +   cd.b);
		
	}
}


