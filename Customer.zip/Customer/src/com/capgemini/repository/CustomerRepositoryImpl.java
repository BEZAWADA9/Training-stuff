package com.capgemini.repository;

import java.util.LinkedList;
import java.util.List;

import com.capgemini.model.Customer;

public class CustomerRepositoryImpl implements CustomerRepository {
	
	List<Customer> customers = new LinkedList<>();
	
	/* (non-Javadoc)
	 * @see com.capgemini.repository.CustomerRepository#findAll()
	 */
	@Override
	public List<Customer> findAll()
	{
		Customer customer = new Customer();
		
		customer.setFirstName("Sachin");
		customer.setLastName("Tendulkar");
		
		customers.add(customer);
		
		return customers;
	}

}
