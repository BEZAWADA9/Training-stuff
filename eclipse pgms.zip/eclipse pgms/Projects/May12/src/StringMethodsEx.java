
public class StringMethodsEx {

	public static void main(String[] args) {
		
         int[] arr=new int[5];
         String[] str=new String[5];
         for(int i=0;i<arr.length;i++){
        	 System.out.println(arr[i]);
         }
        	 
         
         for(int i=0;i<str.length;i++){
        	 System.out.println(str[i]);
	}
         
     
}}
