package studentstore;

public class Student {
	
	private int rollNumber;
	private String name;
	
	
	String coursesTaken[];
	
	
	Student(){
		
	}
	
	public Student(int rollNumber, String name, String[] coursesTaken) {
		super();
		
		System.out.println("I am in constructor");
		this.rollNumber = rollNumber;
		this.name = name;
		
	 this.coursesTaken=coursesTaken;
	 
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public  String[] getCourseNames() {
		return coursesTaken;
	}
	
	
	public void setCourseNames(String[] coursesTaken) {
		
			this.coursesTaken=coursesTaken;
		
	}
	
	
	

	
	
}
