
public class Employee {

	private String name;
	
	public String toString(){ //to convert from 
		
		return name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee(String name) {
		super();
		this.name = name;
	}
	
	
}

