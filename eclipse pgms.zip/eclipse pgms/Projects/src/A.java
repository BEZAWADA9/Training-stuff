
public class A {
	private int i;
	private String[] str=new String[5];
	public A(int i, String[] str) {
		super();
		this.i = i;
		this.str = str;
	}

}
