import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Employee e=new Employee();
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter number of employees you want");
    int n=sc.nextInt();
    Employee[] employee=new Employee[n];
    for(int i=0;i<employee.length;i++)
    {
    	employee[i]=new Employee();
    	employee[i].setName(sc.next());
    }
    for(int i=0;i<employee.length;i++)
    {
    	System.out.println(	"Employees are" +employee[i].getName());
    	
    }
    // e.setAge(23);
    // System.out.println("Employee age is:" +e.getAge());
	}

}
