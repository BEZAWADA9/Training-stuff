import java.util.Scanner;
import studentschedularstore.StudentSchedular;
public class UserInterface {

static	Scanner sc=new Scanner(System.in);
static	StudentSchedular studentSchduler=new StudentSchedular();
static	String[] coursesTaken;
	
	public static void main(String[] args) {
		

		int i=0;
		i=i*i++;
		while(true){
			
			System.out.println("1.add a Student");
			
			System.out.println("2.show the student details");
			
			System.out.println("3.checking courses with rollnumbers");
			
			System.out.println("4.for Exit");
			System.out.println("Enetr your choice");
			
			int selected=sc.nextInt();
			
			switch(selected){
			
			case 1: addStudentDetails();
			        break;
			
			case 2: showStudentDetails();
			        // studentSchduler.displayCourses();
			        break;
			        
			case 3: System.out.println("enter rollnumber to retrieve his courses");
			         studentSchduler.checkCourses(sc.nextInt());
			case 4: System.exit(0);
			}
			
			
		}
		
		
		
	/*	public static  void addStudentDetails(){
			
			System.out.println("enetr student name");
			String name=sc.next();
			
			System.out.println("enetr student rollnumbere");
			int rollNumber=sc.nextInt();
			
			studentSchduler.addStudent(rollNumber, name);
		} */
		 
		
	}


	private static void showStudentDetails() {
		
		System.out.println("i am calling show student deatails");   
		studentSchduler.showAllStudents();
		
	}


	private static void addStudentDetails() {
		System.out.println("enetr student name");
		String name=sc.next();
		
		System.out.println("enetr student rollnumbere");
		int rollNumber=sc.nextInt();
		  
		System.out.println("How many  courses student needs");
		int numberOfCourses=sc.nextInt();
		
		System.out.println("Enter " +numberOfCourses +", As you have chosens ");
		
		 coursesTaken=new  String[numberOfCourses];
		
		for(int i=0; i < numberOfCourses ;i++){
		//	System.out.println("in for loop : i variable : " + i);
			
				coursesTaken[i] = sc.next();
			//	System.out.println("coursesTaken[i]" + coursesTaken[i]);
			
		} 
		//int rollNumber=sc.nextInt();
		
		//System.out.println("Out of for loop");
		
		//System.out.println("course taken" + coursesTaken);
		
	String str=	studentSchduler.addStudent(rollNumber, name, coursesTaken);
		
	System.out.println(str);
	}

}
