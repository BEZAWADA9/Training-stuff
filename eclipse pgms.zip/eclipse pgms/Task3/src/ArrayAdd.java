import java.util.Scanner;
public class ArrayAdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int[] arr=new int[5];
		int[] arr1=new int[5];
		int sum=0;
		System.out.println("enter array elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
			//arr1[0]=0;
			sum=sum+arr[i];
			//sum=arr1[i]; 
			
		}
		
		System.out.println(sum);
		}
		

}
