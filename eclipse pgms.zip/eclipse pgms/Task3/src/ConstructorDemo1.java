
 class ConstructorDemo2 {
	 int a=20;
	ConstructorDemo2()
	{ 
		
		System.out.println("this is parent class");
	}
	
	public void add(){
		System.out.println("parent class method" );
	}
 }
	
	class ConstructorDemo1 extends ConstructorDemo2
	{
		
		public void add(){
			System.out.println("parent class method" );
			
			super.add();
		}
		
		ConstructorDemo1()
	{
			System.out.println("parent class a value is" + super.a);
			
		System.out.println("this is base class");
		
		super.a=15;
		
		System.out.println("parent class a value after having changed is" +super.a);
	}
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConstructorDemo1 cd=new ConstructorDemo1();
	}

	}
