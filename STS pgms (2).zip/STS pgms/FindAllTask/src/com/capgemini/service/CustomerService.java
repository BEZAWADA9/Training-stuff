
package com.capgemini.service;
import com.capgemini.repo.*;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.model.Customer;

public class CustomerService implements ICustomerService {
	 ICustomerRepo cr; // =new CustomerReo();
	public ICustomerRepo getCr() {
		return cr;
	}
	public void setCr(ICustomerRepo cr) {
		this.cr = cr;
	}
	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}
	
		
		
	
	
	
}
