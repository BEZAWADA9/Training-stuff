import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class UsingStatementUpdate {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/murali","root","root");
			
			java.sql.Statement st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			
			
			
			
			java.sql.ResultSet rs=st.executeQuery("select * from  student1");
			
			//rs.insertRow();
			
			while(rs.next()){
				
				System.out.println(rs.getString(1) + " " + rs.getInt(3));
				
				
			}
			
			rs.moveToInsertRow();
		      rs.updateInt("id",104);
		      rs.updateString("first","John");
		      rs.updateString("last","Paul");
		      rs.updateInt("age",40);
		      //Commit row
		      rs.insertRow();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
