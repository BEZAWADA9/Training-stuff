import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
		
		Student std=(Student) context.getBean("student");
		System.out.println(std.getName());
		//System.out.println("Address one is " + std.getAddress());
		System.out.println("Addresses are  " + std.getAddress());
			}

}
