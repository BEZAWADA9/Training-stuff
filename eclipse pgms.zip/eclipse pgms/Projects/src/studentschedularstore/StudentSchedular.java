package studentschedularstore;
import studentstore.Student;
public class StudentSchedular {

	
	Student[] student=new Student[10];
	
	private int  studentCounter;
	
	
	
public	String addStudent(int rollNumber,String name,String[] coursesTaken){
		
	//System.out.println("Before for loop");
	
	for(int i=0; i < studentCounter;i++){
		
		//System.out.println(i);
		
		if(student[i].getRollNumber()==rollNumber){
			return "rollNumber is already existed";
			
		}
	}
	
	System.out.println("course taken: " + coursesTaken);
	
	student[studentCounter++] =new Student(rollNumber, name, coursesTaken);

	//showAllStudents();
	return "Student has been added";
}






	public  void showAllStudents(){
		System.out.println("in showAllStudents");  
	//	System.out.println("StudentCounter : " + studentCounter);
		
		for(int i=0;i<studentCounter;i++){
			
			System.out.println(student[i].getName());
			
			System.out.println(student[i].getRollNumber());
			
			
			displayCourses();	
			
			
			}
			
			//System.out.println(student[i].getRollNumber());
			
			
			
		}
		
		

		
		
  public  void displayCourses(){
		
	  System.out.println("In displaycourse");
	  
	 // System.out.println(studentCounter);
	  
	  for(int i=0;i< studentCounter;i++)
	  {
	//	  System.out.println("i value is" + i);
	 
		//  System.out.println("course length: " + student[i].getCourseNames());
		  
		  for(int j=0; j<student[i].getCourseNames().length;j++){
			
			// System.out.println("j value is" + j);
			System.out.println(" student with rollnumber" + student[i].getRollNumber() +" is taken "+ student[i].getCourseNames()[j] +"Course");
			
		} 
	  }
		
	  
		
	 /*public String toString(){
			
			return 
		} */
	}
  
  public void checkCourses(int rollNumberCheck){
	  for(int i=0;i< studentCounter;i++){
	  
	  if(student[i].getRollNumber()==rollNumberCheck){
		  for(int k=0;k<=student[i].getCourseNames().length;k++){
		   
		  System.out.println(student[i].getCourseNames()[i]);
		  
		  }
	  }
	  else 
		  System.out.println("Rollnumber is not found");
	  }
/*	  for(int i=0;i< student[i].getRollNumber();i++)
	  {
		  
	  }
	  */
	  
  }
	

}