import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadingFileEx1 {

	public static void main(String[] args) throws IOException
	{
		BufferedReader br1=new BufferedReader(new FileReader(new File("D:\\Murali\\Multithreading\\src\\JoinEx.java")));

		
		String line=br1.readLine();
		
		while(line!=null){
			
			System.out.println(line);
			line=br1.readLine();
			}
	}

}
