import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferedReaderEx1 {

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
System.out.println("enter value");

try {
	String str1=br.readLine();
	String str2=br.readLine();
	int n1=Integer.parseInt(str1);
	System.out.println(n1);
	
	
	int n2=Integer.parseInt(str2);
	System.out.println(n2);
	
	System.out.println(n1+n2);
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
