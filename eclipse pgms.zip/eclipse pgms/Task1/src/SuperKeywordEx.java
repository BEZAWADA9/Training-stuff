
  class  SuperKeyword{

       int a,b;
	
	
	public SuperKeyword(int a, int b) {
		
		this.a = a;
		this.b = b;
		 System.out.println("this is super constructor");
	}
}

public class SuperKeywordEx extends SuperKeyword{
	
	SuperKeywordEx(){
		
		super(1,2);
		
		 System.out.println("this is subclass constructor");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperKeywordEx sd=new SuperKeywordEx();
	}

}
