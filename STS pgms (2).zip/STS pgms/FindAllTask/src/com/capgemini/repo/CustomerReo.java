package com.capgemini.repo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Customer;

public class CustomerReo implements ICustomerRepo {
	static int i=1;
	List customerList=new ArrayList();
	
	@Override
	public List<Customer> findAll(){
      Customer customer = new Customer();
		
		customer.setFirstName("Murali");
		customer.setLastName("Bezawada");
		customerList.add(customer);
		return customerList;
		/*System.out.println(i + " Iteration ");
		Iterator cust=customerList.iterator();
		while(cust.hasNext()){
		System.out.println("Customers are " + cust.next());
		
		}
		i++;*/
		/*
		for(Customer customer:(Customer)customerList){
			System.out.println(customer);
		}*/
		
		
	}
}
