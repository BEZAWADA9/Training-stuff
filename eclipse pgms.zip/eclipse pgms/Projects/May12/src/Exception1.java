
public class Exception1 {

	public static void main(String[] args) {
		try{
			System.out.println("1");
		int a=10;
		int b=0;
		int c;
		try{
			System.out.println(2);
			c=a/b;
		
	//	System.out.println("exception handled");
		
		}
		
		catch(NullPointerException  e)
		{
			System.out.println(e);
		}
		catch(ArithmeticException ae1){
			System.out.println("this is inner try");
			System.out.println(ae1);
		}
		
		System.out.println("exception handled1");
		
		}
	//	System.out.println("exception handled2");
		catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("this is outer try");
			System.out.println(ae);
		}
		
		catch(ArithmeticException ae1){
			System.out.println("this is outer try");
			System.out.println(ae1);
		}
		
		System.out.println("out");
		
	}

}
