
public class ForLoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   // int j=0;
      
	for(int i=0, j=0, k=0, l=0;i<=5;i++, j++, k++, l++)
		{
		
			System.out.println("i value is" + i);
			System.out.println("j value is" + j++);
		} 
		//System.out.println(j);
	}

}
