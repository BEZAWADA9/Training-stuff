
public class Parent {

void add(){
		System.out.println("This is add method in parent class");
	}
	
	void sub(){
		System.out.println("This is sub method in parent class");
	}
	
}
